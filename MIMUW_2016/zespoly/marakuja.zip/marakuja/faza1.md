## Komentarze:

Ubogi ten wykres i w dodatku trudnie z niego coś odczytać.
A bez tytułu i komentarzy nawet nie wiadomo co można by z niego odczytać.

