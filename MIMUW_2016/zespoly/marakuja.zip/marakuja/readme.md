Zespół Marakuja
===============

Skład zespołu
--------------

* Anna Prochowska
* Szymon Dziewiątkowski
* Michał Łuszczyk


Obowiązki
----------

* Kontakt na zewnątrz - Szymon
* Specyfikacja wymagań - Michał
* Opieka nad kodem - Ania
* Opieka nad częścią analityczną - Ania
* Opieka nad częścią wizualną - Szymon
* Opieka nad dokumentacją końcową - Michał

Temat
------

Zależności między ocenami z przedmiotów.
