PROCESSED_GRADES_CSV_PATH = "../first_grade_marks.csv"
COURSES_LIST_PATH = "../courses.csv"

DRIVER_CLASS <- "oracle.jdbc.OracleDriver"
DRIVER_CLASS_PATH <- "ojdbc6.jar"

HOST <- "usos.edu.pl"
PORT <- 1521
SERVICE_NAME <- "USOS"

USER <- "user"
PASSWORD <- "password"

CODE_PREFIX <- "1000-"