packages <- c("ggplot2", "dplyr", "shiny", "stringr", "RJDBC")
install.packages(packages)
