## Komentarze:

1. Jak rozumiem, używanie rozszerzenia DAT zamiast rda to próba utrudnienia dostępu do danych osobom niepowołanym?

2. Skrypty solidnie napisane, ale znacznie lepiej byłoby wszędzie używać knitra.
 [teraz jest prawie wszędzie, ale są dwa pliki bez knitra].
 Nawet jeżeli coś będzie uruchomione tylko raz (tak jak generate.r) i ma zapisać pobrane dane do pliku, to wciąż lepiej użyć knitra. Dzięki temu, komentarze będą mogły być bardziej rozbudowane niż inline po #. 

3. W kodzie 'charts_a.R' mają Państwo dużo magicznych stałych (np. wagi na punkty z egzaminów). 
Gdyby całość była w knitrze to można by nie tylko opisać skąd są te stałe (wstawić link do źródła) ale też słownie skomentować że to są składowe rekrutacji i są różne na różnych uczelniach. Za dwa miesiące nawet autor tego skryptu może o tym zapomnieć.
To wszystko jest co prawda opisane w pliku 'Opis metodologii', ale najlepiej by było w każdym skrypcie gdzie te stałe występują,  dać link do pliku z opisem.

4. Dlaczego część wyników jest w pdf a część w html? Czy nie lepiej byłoby wszystko kompilować do html?

5. Dlaczego w pliku 'opis metodologii' na różnych wykresach są przedstawione różne szkoły?

6. Bardzo podoba mi się plan. Widać i metodyczne podejście do tematu i sporo sensownie włożonej pracy. Czekam na wyniki z kolejnej fazy.

