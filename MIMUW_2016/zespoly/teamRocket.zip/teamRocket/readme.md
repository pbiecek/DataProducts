Nazwa Zespołu
---

__*Team Rocket*__

Skład
---

* Piotr Bakalarski <pb358995@students.mimuw.edu.pl>
* Bartek Bancerek <bb332063@students.mimuw.edu.pl>
* Mateusz Macias <mm332321@students.mimuw.edu.pl>
* Adrianna Traczyk <at360392@students.mimuw.edu.pl>

Role
---

* Kontakt na zewnątrz: Adrianna
* Specyfikacja wymagań: Adrianna
* Opieka nad kodem: Piotr
* Opieka nad częścią analityczną: Mateusz 
* Opieka nad częścią wizualną: Bartek
* Opieka nad dokumentacją końcową: Mateusz


Temat
---

Porównanie wyników matur ze szkół ponadgimnazjalnych w danym rejonie pod kątem rekrutacji na wybrane kierunki studiów.

Instalacja
---
```R
devtools::install_github(repo = "piotrb5e3/dataproducts", ref="devel", subdir="/MIMUW_2016/zespoly/teamRocket/package")
```
Niestety taka metoda pobiera dużo nadmiarowych danych. Ostrożnie!
