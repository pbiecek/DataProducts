## Komentarze:

To tylko plan. 
Zwinne budowanie aplikacji polega na tym, by jak najszybciej mieć prototyp, który można zobaczyć i poprawiać.
Na bazie tego planu niewiele można powiedzieć o docelowym rozwiązaniu.


