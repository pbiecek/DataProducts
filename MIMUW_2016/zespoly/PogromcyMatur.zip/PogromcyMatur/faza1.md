## Komentarze:

1. Na zajęciach pokazywali Panowie inną aplikację (w google vis) niż ta na githubie. Na githubie powinny być prezentowane na zajęciach rozwiązania, przynajmniej po to by inne zespoły mogły z nich skorzystać.

2. Łączenie się z bazą danych za każdym razem gdy ktoś zmieni coś w menu to zły pomysł. Baza jest tutaj statyczna, zmienia się raz na rok. Jest na słabym serwerze i takie rozwiązanie będzie powodowało nieustanne problemy z działaniem.
Znacznie lepiej w cache aplikacji umieścić dane na których pracuje (lub zrobić lokalny mirror bazy, tylko na potrzeby tej aplikacji).

3. Obecnie interface jest bardzo ubogi, przez co nie wiadomo jakie wartości wpisać do których pól. A bez tego cała aplikacja nie działa i po około 30 sek się wyłącza.

4. Bez domyślnych wartości w interface i bez choćby szczątkowego opisu w aplikacji, nie sposób z niej skorzystać.

