# Nazwa zespołu

 PogromcyMatur

Temat: Analiza średnich wyników szkół z poszczególnych części egzaminów w zależności od poziomu uczniów rekrutowanych przez szkoły.
=======
## Sklad zespolu

1. Michal Waszczuk:
   * kontakt na zewnatrz
   * opieka nad czescia wizualna
2. Franciszek Piszcz:
   * opieka nad kodem
   * opieka nad dokumentacja koncowa
3. Igor Kotrasinski: 
   * opieka nad czescia analityczna
   * specyfikacja wymagan

##Temat

Analiza szczegółowych wyników egzaminów w zależności od różnych czynników różnicujących uczniów, takich jak płeć, uczęszczana szkoła czy wyniki z poprzednich egzaminów.
