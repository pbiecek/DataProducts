### Nazwa zespołu:
mimkatz

### Skład zespołu: 
* Magdalena Waśniowska
* Katarzyna Herba
* Marcin Kania (martin.kania@gmail.com)

### Tytuł realizowanego tematu:
Matura a studia: Czy wyniki z matury mają istotny wpływ na przeżywalność studentów przy pierwszym, drugim i trzecim odsiewie? Czy istnieje korelacja między ocenami z przedmiotów i średnią ocen, a wynikami z matury i średnim wynikiem? Czy student MIMu jest maturalnym specjalistą, czy maturalnie renesansowy?

### Kontakt na zewnątrz: 
Marcin Kania

### Specyfikacja wymagań:
Katarzyna Herba

### Opieka nad kodem:
Marcin Kania

### Opieka nad częścią analityczną:
Magdalena Waśniowska

### Opieka nad częścią wizualną:
Katarzyna Herba, Marcin Kania

### Opieka nad dokumentacją końcową:
Marcin Kania
