## Komentarze:

1. Ciekawa analiza. Moim zdaniem lepsze do zaprezentowania na zajęciach byłyby wnioski z pierwszej części (interesujące), niekoniecznie ten ostatni graf (który jeszcze trzeba dopracować, bo teraz trudno się go czyta). Wiem że sugerowałem aby wybrać tylko jedną najlepszą rzecz, ale tą rzeczą jest raczej wykres słupkowy z ocenami (może ten kolorowy).

2. PRAC_ID_1 to zmienna numeric, przez to kolory ma rozpięte od niebieskiego po czarny. Znacznie lepiej byłoby zamienić ja na factor i wtedy kolory byłyby łatwiejsze ro rozróżnienia. W tej chwili z tej skali kolorów nic nie wynika.

3. Prezentując wyniki dla semestrów, kolejność odpowiadająca latom jest ok. Ale prezentując wyniki dla pracowników, zamiast pokazywać numerki po kolei lepiej pracowników posortować względem jakiegoś kryterium (np. wyników jego grupy).

4. W kolejnym kroku, proszę już pracować na bazie danych USOSa. Są to dane lepszej jakości niż te w pliku tekstowym.

