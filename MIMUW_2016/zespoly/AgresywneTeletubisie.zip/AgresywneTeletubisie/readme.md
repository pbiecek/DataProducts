###Nazwa Zespolu


AgresywneTeletubisie

##Sklad zespolu

Radomir Nowacki e-mail: rnowacki@student.uw.edu.pl

Matuesz Chołołowicz e-mail: mc359057@students.mimuw.edu.pl

###Odpowiedzialni za poszczególne części


Kontakt na zewnątrz: Radomir

Specyfikacja wymagań: Mateusz

Opieka nad kodem: Mateusz

Opieka nad częścią analityczną: Radomir

Opieka nad częścią wizualną: Radomir

Opieka nad dokumentacją końcową: Mateusz


###Tytul realizowanego tematu


Budowa analitycznego narzędzia służącego do porównywania szkół w wybranym regionie Polski.

Link do commitów z repozytorium na bitbuckecie, na którym miała miejsce cała historia zmian projektu:
https://bitbucket.org/xantore/jnp2/commits/all
